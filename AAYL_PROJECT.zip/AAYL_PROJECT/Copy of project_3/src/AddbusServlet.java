import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class AddbusServlet	extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();  
HttpSession session=request.getSession(false);  
if(session!=null){  
//request.getRequestDispatcher("link.html").include(request, response);  

//int busid=Integer.parseInt(request.getParameter("busid"));  
Random randomGenerator = new Random();

int randomInt = randomGenerator.nextInt(100);
int busid=randomInt;

String bustype=request.getParameter("bustype"); 
String fromstation=request.getParameter("fromstation");  
String tostation=request.getParameter("tostation"); 
String arrivaltime=request.getParameter("arrivaltime");
String departuretime=request.getParameter("departuretime"); 
String traveltime=request.getParameter("traveltime"); 
String route=request.getParameter("route"); 
int fare=Integer.parseInt(request.getParameter("fare")); 
int seats=Integer.parseInt(request.getParameter("seats")); 
//System.out.println(user+email+password+passwordr);
int val = 0 ;
	try {
		val = validate(busid,bustype,fromstation,tostation,arrivaltime,departuretime,traveltime,route,fare,seats);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

if(val==1)
{
//if(password.equals("admin123")){  
	String message = "You are successfully added!";
	//System.out.println(message);
	request.setAttribute("message",message);
	
	String message1 = "Your busid is"+busid;
	//System.out.println(message);
	request.setAttribute("message1",message1);
	
	
	
//out.println("You are successfully added!");  
//out.print("<br>Welcome, "+user);  
//out.println("Your busid is"+busid);
//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
	RequestDispatcher dispatcher = request.getRequestDispatcher("addedjsp.jsp");
	dispatcher.forward( request, response ); 



}else{  
	String message = "sorry error occurred!";
	//System.out.println(message);
	request.setAttribute("message",message);
	
	
//out.println("You are successfully added!");  
//out.print("<br>Welcome, "+user);  
//out.println("Your busid is"+busid);
//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
	RequestDispatcher dispatcher = request.getRequestDispatcher("addedjsp.jsp");
	dispatcher.forward( request, response ); 


//request.getRequestDispatcher("Signup.html").include(request, response); 
}  

out.close();  

}  
else{  
    out.print("Please login first");  
    request.getRequestDispatcher("Home1.jsp").include(request, response);  
} }



//protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
//doGet(request, response);

//}
public int validate(int busid,String bustype,String fromstation,String tostation,String arrivaltime,String departuretime,String traveltime,String route,int fare,int seats) throws SQLException
{
Connection con=null;
int flag = 0;
int flag1=0;
try {
  Class.forName("org.apache.derby.jdbc.ClientDriver");
//Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
      //Class.forName("oracle.jdbc.driver.OracleDriver");
} catch (ClassNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
}

try {
      // con=DriverManager.getConnection("jdbc:derby://172.24.21.35:1527/derby","user","user");
       con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample;create=true","user","pwd");
      //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
} catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
}

//Connection con = ConnectionManager.getConnection();
try{
PreparedStatement stmt1=null;
Statement stmt=null;
//ResultSet resultset=null;


			
String searchQuery= "insert into T_XBBNHGN_BUS  values(?,?,?,?,?,?,?,?,?,?) ";
stmt1 =con.prepareStatement(searchQuery);	
stmt1.setInt(1,busid);
stmt1.setString(2,bustype);
stmt1.setString(3,fromstation);
stmt1.setString(4,tostation);
stmt1.setString(5,arrivaltime);
stmt1.setString(6,departuretime);
stmt1.setString(7,traveltime);
stmt1.setString(8,route);
stmt1.setInt(9,fare);
stmt1.setInt(10,seats);
//System.out.println(busid+bustype+fromstation+tostation+arrivaltime+departuretime+traveltime+route+fare+seats);
 flag= stmt1.executeUpdate();
 
 String searchQuery1= "insert into T_XBBNHGN_TICKET  values(?,?,?,?,?,?,?,?,?) ";
 stmt1 =con.prepareStatement(searchQuery1);	
 stmt1.setString(1,null);
 stmt1.setInt(2,busid);
 stmt1.setString(3,bustype);
 stmt1.setString(4,fromstation);
 stmt1.setString(5,tostation);
 stmt1.setString(6,arrivaltime);
 stmt1.setString(7,departuretime);
 
 stmt1.setInt(8,fare);
 stmt1.setInt(9,seats);
 //System.out.println(busid+bustype+fromstation+tostation+arrivaltime+departuretime+traveltime+route+fare+seats);
 flag1 = stmt1.executeUpdate();

}
catch (SQLException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
}

if(flag==0&&flag1==0)
{
      return 0;
      //System.out.println("True");
}
else
{
return 1;
      //System.out.println("False");
}

}

}







