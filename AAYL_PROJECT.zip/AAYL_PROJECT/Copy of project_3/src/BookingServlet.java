import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class BookingServlet 	extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();  
HttpSession session=request.getSession(false);  
if(session!=null){  

//request.getRequestDispatcher("link.html").include(request, response);  

int busid=Integer.parseInt(request.getParameter("id")); 

//int busid=request.getParameter("id");
String journeydate=request.getParameter("journeydate");
String bustype=request.getParameter("type"); 
String fromstation=request.getParameter("fromstation");  
String tostation=request.getParameter("tostation"); 
int seats=Integer.parseInt(request.getParameter("seats")); 
int val = 0 ;

//System.out.println(user+email+password+passwordr);

	try {
		val = validate(busid,bustype,fromstation,tostation,seats,journeydate);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

if(val==1)
{
//if(password.equals("admin123")){  

//out.print("You are successfully added!"); 
	request.getRequestDispatcher("ViewSeatServlet").include(request, response); 
//out.print("<br>Welcome, "+user);  

//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
//response.sendRedirect("home.jsp");
}
else if(val==4)
{
	out.print("exception occured");
}

else{  

out.println("sorry error occurred!");  
out.println("TryAgain!!");
//request.getRequestDispatcher("Signup.html").include(request, response); 
}  

out.close();  
}  else{  
    out.print("Please login first");  
    request.getRequestDispatcher("index.jsp").include(request, response);  
} }



//protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
//doGet(request, response);

//}
public int validate(int busid,String bustype,String fromstation,String tostation,int seats,String journeydate) throws SQLException
{
Connection con=null;
int flag = 0;
int val = 0;
int val1=0;
try {
  Class.forName("org.apache.derby.jdbc.ClientDriver");
//Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
      //Class.forName("oracle.jdbc.driver.OracleDriver");
} catch (ClassNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
}

try {
      // con=DriverManager.getConnection("jdbc:derby://172.24.21.35:1527/derby","user","user");
       con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample;create=true","user","pwd");
      //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
} catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
}


String sq= "update T_XBBNHGN_Ticket set journey_date=? where bus_id=? ";
PreparedStatement statement = con.prepareStatement(sq);
statement.setString(1,journeydate );

statement.setInt(2, busid);
statement.executeUpdate();


//Connection con = ConnectionManager.getConnection();
String sql1 = "select distinct  * from T_XBBNHGN_Ticket where journey_date=? and bus_id=? and bus_type=? ";
PreparedStatement statement1 = con.prepareStatement(sql1);
statement1.setString(1,journeydate );
statement1.setString(3,bustype );
statement1.setInt(2, busid);
System.out.println(journeydate+busid+bustype);
//stmt11.setString(3, tostation);
//System.out.println("hi"); 
ResultSet resultset = statement1.executeQuery();
//System.out.println(resultset);
 while(resultset.next())
	{
		//Ticketbean cbean=new Ticketbean();
						
			//cbean.setBus_id(resultset.getInt(1));
			//cbean.setBustype(resultset.getString(2));
		//System.out.println(resultset);
		//clist.add(cbean); 
	
	
 //String  searchQuery1="insert into T_XBBNHGN_TICKET values '"+journeydate+"' select bus_id,bus_type,from_station,to_station,arrival_time,departure_time,fare,seats from T_XBBNHGN_BUS where bus_type= '"+bustype+"' and from_station='"+fromstation+"'  and to_station= '"+tostation+"' ";
 //String  searchQuery1="insert into T_XBBNHGN_TICKET values( '"+journeydate+"','"+resultset.getInt(1)+"','"+resultset.getString(2)+"','"+resultset.getString(3)+"','"+resultset.getString(4)+"','"+resultset.getString(5)+"','"+resultset.getString(6)+"','"+resultset.getInt(9)+"','"+resultset.getInt(10)+"' )";
 //String s1="insert into T_XBBNHGN_TICKET(journey_date) values '"+journeydate+"'where bus_type= '"+bustype+"' and from_station='"+fromstation+"'  and to_station= '"+tostation+"' ";
 //val=stmt1.executeUpdate(searchQuery1);			 
// stmt.executeUpdate(s1);
		//System.out.println("hii");
		String sql = "INSERT INTO T_XBBNHGN_TICKETADMIN VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		statement = con.prepareStatement(sql);
		statement.setString(1, journeydate);
		statement.setInt(2,busid);
		statement.setString(3, resultset.getString(3));
		statement.setString(4,resultset.getString(4));
		statement.setString(5,resultset.getString(5));
		statement.setString(6,resultset.getString(6));
		statement.setString(7,resultset.getString(7));
		statement.setInt(8,resultset.getInt(8));
		statement.setInt(9,resultset.getInt(9));
		val = statement.executeUpdate();
		
		String sql11 = "INSERT INTO T_XBBNHGN_TICKETUSER VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		statement = con.prepareStatement(sql11);
		statement.setString(1, journeydate);
		statement.setInt(2,busid);
		statement.setString(3, resultset.getString(3));
		statement.setString(4,resultset.getString(4));
		statement.setString(5,resultset.getString(5));
		statement.setString(6,resultset.getString(6));
		statement.setString(7,resultset.getString(7));
		statement.setInt(8,resultset.getInt(8));
		statement.setInt(9,seats);
		val1 = statement.executeUpdate();
		
 
 
 }


int sum=0;

//while(resultset.next())
//{
	//sum=sum+resultset.getInt(9);
//}
//System.out.println(sum);
Statement stmt=con.createStatement();
ResultSet rs=null;
String no="select  availableseats from T_XBBNHGN_Ticketadmin where bus_id=? and journey_date=?";
PreparedStatement statement11 = con.prepareStatement(no);
statement11.setString(2, journeydate);
statement11.setInt(1,busid);
rs=statement11.executeQuery();
while(rs.next())
{

int num=rs.getInt(1);

//int num=Integer.parseInt(no);
System.out.println(num);
System.out.println(seats);
int totalseats=num-seats;
System.out.println(totalseats);
//ResultSet rs=stmt.executeQuery(query);
//int no_seat=0;
//while(rs.next())
//{
	//no_seat=Integer.parseInt(rs.getString(1));
//}
//System.out.print(no_seat);


//String a1="select no_of_seats from T_XBBNHGN_Ticket where where journey_date=? and bus_id=? ";
if(totalseats<0)
{
	val=4;
}
else if(totalseats==0||totalseats>0)
{
 String searchQuery1= "update T_XBBNHGN_Ticketadmin set availableseats=? where bus_id=? and journey_date=?";
 statement = con.prepareStatement(searchQuery1);
 statement.setInt(1,totalseats);
	statement.setInt(2,busid);
	statement.setString(3, journeydate);

 
 val=statement.executeUpdate();
 
 
 String searchQuery2= "update T_XBBNHGN_Ticket set no_of_seats=? where bus_id=? and journey_date=?";
 statement = con.prepareStatement(searchQuery2);
 statement.setInt(1,totalseats);
	statement.setInt(2,busid);
	statement.setString(3, journeydate);

 
 val=statement.executeUpdate();
}
}

return val;


}
}



