import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CancelticketServlet  extends HttpServlet {
	 protected void doGet(HttpServletRequest request, HttpServletResponse response)  
	            throws ServletException, IOException {  
	response.setContentType("text/html");  
	PrintWriter out=response.getWriter();  

	//request.getRequestDispatcher("link.html").include(request, response);  
	HttpSession session=request.getSession(false);  
    if(session!=null){  

	int busid=Integer.parseInt(request.getParameter("id"));  
	
	int val = 0 ;
	try {
		val = validate(busid);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

if(val==1)
{
//if(password.equals("admin123")){  

//out.print("successfully canceled!");  
//out.print("<br>Welcome, "+user);  
String message = "Successfully cancelled";
//System.out.println(message);
request.setAttribute("message",message);



//out.println("You are successfully added!");  
//out.print("<br>Welcome, "+user);  
//out.println("Your busid is"+busid);
//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
RequestDispatcher dispatcher = request.getRequestDispatcher("Editprofilejsp.jsp");
dispatcher.forward( request, response ); 

//out.print("You have successfully paid!"); 
request.getRequestDispatcher("paymentcash.jsp").include(request, response);
//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
//response.sendRedirect("home.jsp");
}else{  
	String message = "Sorry!!! error occured..try again!!";
	//System.out.println(message);
	request.setAttribute("message",message);
	
	
	
//out.println("You are successfully added!");  
//out.print("<br>Welcome, "+user);  
//out.println("Your busid is"+busid);
//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
	RequestDispatcher dispatcher = request.getRequestDispatcher("Editprofilejsp.jsp");
	dispatcher.forward( request, response ); 

//out.println("sorry error occurred!");  
//out.println("TryAgain!!");
//request.getRequestDispatcher("Signup.html").include(request, response); 
}  

out.close();  
}  else{  
    out.print("Please login first");  
    request.getRequestDispatcher("index.jsp").include(request, response);  
} }

	
	 public int validate(int busid) throws SQLException
	 {
	
	Connection con=null;
	int flag = 0;
	try {
	      Class.forName("org.apache.derby.jdbc.ClientDriver");
	      //Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	try {
	       con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample;create=true","user","user");
	      //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
	} catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	//Connection con = ConnectionManager.getConnection();
	try{
	PreparedStatement stmt1=null;
	Statement stmt=null;
	//ResultSet resultset=null;

	
	
	String searchQuery= "delete from T_XBBNHGN_BOOKING where Ticket_id=?";
	
	stmt1 =con.prepareStatement(searchQuery);
	stmt1.setInt(1,busid);
		flag= stmt1.executeUpdate();
		
		  
		System.out.println("Ticket cancelled successfully"); 
	 }
	 catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}
	if(flag==0)
	{
	      return 0;
	      //System.out.println("True");
	}
	else
	{
	return 1;
	      //System.out.println("False");
	}
	
	 }

}
