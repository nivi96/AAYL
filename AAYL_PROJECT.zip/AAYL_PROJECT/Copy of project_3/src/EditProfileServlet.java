import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class EditProfileServlet  extends HttpServlet {
	 protected void doGet(HttpServletRequest request, HttpServletResponse response)  
	            throws ServletException, IOException {  
	response.setContentType("text/html");  
	PrintWriter out=response.getWriter();  

	//request.getRequestDispatcher("link.html").include(request, response);  
	
	HttpSession session=request.getSession(false);  
    if(session!=null){  

	int customerid=Integer.parseInt(request.getParameter("id"));  
	//String option=request.getParameter("option");
	if(request.getParameter("option").equals("age")||request.getParameter("option").equals("contactno"))
	{
		String option1=request.getParameter("option");
		int p1=Integer.parseInt(request.getParameter("parameter"));
		//int busid=Integer.parseInt(request.getParameter("busid"));
		//int busid1=Integer.parseInt(request.getParameter("busid"));
		//System.out.println(busid1);
		
		int val = 0 ;
		try {
			val = validate1(customerid,option1,p1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(val==1)
		{
		//if(password.equals("admin123")){  

		//out.print("Details successfully modified!");  
			String message = "Details modified Successfully";
			//System.out.println(message);
			request.setAttribute("message",message);
			
			
			
		//out.println("You are successfully added!");  
		//out.print("<br>Welcome, "+user);  
		//out.println("Your busid is"+busid);
		//Cookie ck=new Cookie("user",user);  
		//response.addCookie(ck);  
			RequestDispatcher dispatcher = request.getRequestDispatcher("Editprofilejsp.jsp");
			dispatcher.forward( request, response ); 
		//out.print("<br>Welcome, "+user);  

		//Cookie ck=new Cookie("user",user);  
		//response.addCookie(ck);  
		//response.sendRedirect("home.jsp");
		}else{  
			
			String message = "Sorry...!!Try Again";
			//System.out.println(message);
			request.setAttribute("message",message);
			
			
			
		//out.println("You are successfully added!");  
		//out.print("<br>Welcome, "+user);  
		//out.println("Your busid is"+busid);
		//Cookie ck=new Cookie("user",user);  
		//response.addCookie(ck);  
			RequestDispatcher dispatcher = request.getRequestDispatcher("Editprofile.jsp");
			dispatcher.forward( request, response ); 


		//out.println("sorry error occurred!");  
		//out.println("TryAgain!!");
		//request.getRequestDispatcher("Signup.html").include(request, response); 
		}  

		out.close();  
		
		} 

	
	else
	{
		String option=request.getParameter("option");
		String p=request.getParameter("parameter");
		
		int val = 0 ;
		try {
			val = validate(customerid,option,p);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(val==1)
		{
		//if(password.equals("admin123")){  
			String message = "Details modified Successfully";
			//System.out.println(message);
			request.setAttribute("message",message);
			
			
			
		//out.println("You are successfully added!");  
		//out.print("<br>Welcome, "+user);  
		//out.println("Your busid is"+busid);
		//Cookie ck=new Cookie("user",user);  
		//response.addCookie(ck);  
			RequestDispatcher dispatcher = request.getRequestDispatcher("Editprofilejsp.jsp");
			dispatcher.forward( request, response ); 

		//out.print("Details successfully modified!");  
		//out.print("<br>Welcome, "+user);  

		//Cookie ck=new Cookie("user",user);  
		//response.addCookie(ck);  
		//response.sendRedirect("home.jsp");
		}else{  
			String message = "Sorry...!!Try Again";
			//System.out.println(message);
			request.setAttribute("message",message);
			
			
			
		//out.println("You are successfully added!");  
		//out.print("<br>Welcome, "+user);  
		//out.println("Your busid is"+busid);
		//Cookie ck=new Cookie("user",user);  
		//response.addCookie(ck);  
			RequestDispatcher dispatcher = request.getRequestDispatcher("Editprofile.jsp");
			dispatcher.forward( request, response ); 

		//out.println("sorry error occurred.........!");  
		//out.println("TryAgain!!");
		//request.getRequestDispatcher("Signup.html").include(request, response); 
		}  

		out.close();  
		} }  else{  
		    out.print("Please login first");  
		    request.getRequestDispatcher("index.jsp").include(request, response);  
		}



	
	
	
	//System.out.println(user+email+password+passwordr);
	

	
	}  



	//protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	//doGet(request, response);

	//}
	public int validate(int customerid,String option,String p) throws SQLException
	{
	Connection con=null;
	int flag = 0;
	try {
	      Class.forName("org.apache.derby.jdbc.ClientDriver");
	      //Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	try {
	       con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample","user","user");
	      //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
	} catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	//Connection con = ConnectionManager.getConnection();
	try{
	PreparedStatement stmt1=null;
	Statement stmt=null;
	//ResultSet resultset=null;


				
	//System.out.println("Enter the detail you have to modify:");
	//System.out.println("1.Bustype\n2.fromstation\n3.tostation\n4.arrivaltime\n5.departuretime\n6.traveltime\n7.route\n8.fare\n9.seat");

	
		System.out.println(option);
		switch(option)
		{
		case "name":
		{
			//stmt =con.createStatement();
			String searchQuery1= "update T_XBBNHGN_PROFILE set name=? where customer_id=?";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,customerid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
			// System.out.println(p);
			   System.out.println("name updated succesfully");
	}break;
		
		case "gender":
		{
			
			//stmt =con.createStatement();
			
			String searchQuery1= "update T_XBBNHGN_PROFILE set gender=? where customer_id=? ";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,customerid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("gender updated succesfully");
		}break;
		case "address":
		{
			
			
			
			String searchQuery1= "update T_XBBNHGN_PROFILE set address=? where cutsomer_id=?";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,customerid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("address updated succesfully");
		}break;
		case "city":
		{
			
			String searchQuery1= "update T_XBBNHGN_PROFILE set city=? where customer_id=?";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,customerid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("City updated succesfully");
		}break;
		case "email":
		{
			
			String searchQuery1= "update T_XBBNHGN_PROFILE set email=? where customer_id=?";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,customerid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("email updated succesfully");
			
		}break;
		
		}}
		catch (SQLException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		}
		if(flag==1)
		{
		      return 1;
		      //System.out.println("True");
		}
		else
		{
		return 0;
		      //System.out.println("False");
		}
	
	}
	public int validate1(int customerid,String option1,int p1) throws SQLException
	{
	Connection con=null;
	int flag = 0;
	
	try {
	      Class.forName("org.apache.derby.jdbc.ClientDriver");
	      //Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	try {
	       con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample","user","user");
	      //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
	} catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	//Connection con = ConnectionManager.getConnection();
	try{
	PreparedStatement stmt1=null;
	Statement stmt=null;
	//ResultSet resultset=null;


				
	//System.out.println("Enter the detail you have to modify:");
	//System.out.println("1.Bustype\n2.fromstation\n3.tostation\n4.arrivaltime\n5.departuretime\n6.traveltime\n7.route\n8.fare\n9.seat");

	
		
		switch(option1)
		{
	
		case "age":
		{
			//System.out.println(busid1);
			
			String searchQuery1= "update T_XBBNHGN_PROFILE set age=? where customer_id=? ";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setInt(1,p1);
			stmt1.setInt(2,customerid);
			//System.out.println(p1);
		
			flag= stmt1.executeUpdate();
				   System.out.println("Age updated succesfully");
		}break;
		case "contactno":
		{
			
			
			String searchQuery1= "update T_XBBNHGN_PROFILE set contact_no=? where customer_id=? ";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setInt(1,p1);
			stmt1.setInt(2,customerid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("seats updated succesfully");
		}break;
		

	}
	}
	catch (SQLException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

	if(flag==1)
	{
	      return 1;
	      //System.out.println("True");
	}
	else
	{
	return 0;
	      //System.out.println("False");
	}

	}
}
