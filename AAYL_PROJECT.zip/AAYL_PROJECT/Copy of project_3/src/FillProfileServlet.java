import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class FillProfileServlet extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();  

HttpSession session=request.getSession(false);  
if(session!=null){  

//request.getRequestDispatcher("link.html").include(request, response);  

//int busid=Integer.parseInt(request.getParameter("busid"));  
Random randomGenerator = new Random();

int randomInt = randomGenerator.nextInt(100);
int customerid=randomInt;

String name=request.getParameter("name"); 
String gender=request.getParameter("gender");  
int  age=Integer.parseInt(request.getParameter("age")); 
String address=request.getParameter("address");
String city=request.getParameter("city"); 
int contactno=Integer.parseInt(request.getParameter("contactno")); 
String email=request.getParameter("email"); 
//int fare=Integer.parseInt(request.getParameter("fare")); 
//int seats=Integer.parseInt(request.getParameter("seats")); 
//System.out.println(user+email+password+passwordr);
int val = 0 ;
	try {
		val = validate(customerid,name,gender,age,address,city,contactno,email);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

if(val==1)
{
//if(password.equals("admin123")){  
	String message = "You are successfully added!";
	//System.out.println(message);
	request.setAttribute("message",message);
	
	String message1 = "Your customerid  is"+customerid;
	//System.out.println(message);
	request.setAttribute("message1",message1);
	
	
	
//out.println("You are successfully added!");  
//out.print("<br>Welcome, "+user);  
//out.println("Your busid is"+busid);
//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
	RequestDispatcher dispatcher = request.getRequestDispatcher("FillProfilejsp.jsp");
	dispatcher.forward( request, response ); 

request.getRequestDispatcher("CustomeridServlet").include(request, response); 
//out.print("<br>Welcome, "+user);  

//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
//response.sendRedirect("home.jsp");
}else{  

	
	String message1 = "Sorry..!!Try again";
	//System.out.println(message);
	request.setAttribute("message1",message1);
	
	
	
//out.println("You are successfully added!");  
//out.print("<br>Welcome, "+user);  
//out.println("Your busid is"+busid);
//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
	RequestDispatcher dispatcher = request.getRequestDispatcher("FillProfile.jsp");
	dispatcher.forward( request, response ); 

request.getRequestDispatcher("CustomeridServlet").include(request, response); 
//out.print("<br>Welcome, "+user);  

//Cookie ck=new Cookie("user",user);  
out.println("sorry error occurred!");  
out.println("TryAgain!!");
//request.getRequestDispatcher("Signup.html").include(request, response); 
}  

out.close();  
}   else{  
    out.print("Please login first");  
    request.getRequestDispatcher("index.jsp").include(request, response);  
}}



//protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
//doGet(request, response);

//}
public int validate(int customerid,String name,String gender,int age,String address,String city,int contactno,String email) throws SQLException
{
Connection con=null;
int flag = 0;
try {
  Class.forName("org.apache.derby.jdbc.ClientDriver");
//Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
      //Class.forName("oracle.jdbc.driver.OracleDriver");
} catch (ClassNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
}

try {
      // con=DriverManager.getConnection("jdbc:derby://172.24.21.35:1527/derby","user","user");
       con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample;create=true","user","pwd");
      //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
} catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
}

//Connection con = ConnectionManager.getConnection();
try{
PreparedStatement stmt1=null;
Statement stmt=null;
//ResultSet resultset=null;


			
String searchQuery= "insert into T_XBBNHGN_PROFILE  values(?,?,?,?,?,?,?,?) ";
stmt1 =con.prepareStatement(searchQuery);	
stmt1.setInt(1,customerid);
stmt1.setString(2,name);
stmt1.setString(3,gender);
stmt1.setInt(4,age);
stmt1.setString(5,address);
stmt1.setString(6,city);
stmt1.setInt(7,contactno);
stmt1.setString(8,email);


//System.out.println(busid+bustype+fromstation+tostation+arrivaltime+departuretime+traveltime+route+fare+seats);
 flag= stmt1.executeUpdate();

}
catch (SQLException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
}

if(flag==0)
{
      return 0;
      //System.out.println("True");
}
else
{
return 1;
      //System.out.println("False");
}

}
}


