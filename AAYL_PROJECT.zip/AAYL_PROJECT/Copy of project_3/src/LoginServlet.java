
import java.io.IOException;  
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;  
import javax.servlet.http.Cookie;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
public class LoginServlet extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)  
                           throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
          
        //request.getRequestDispatcher("link.html").include(request, response);  
          
        String user=request.getParameter("uname");  
        String password=request.getParameter("psw");  
        int val=validate(user,password);
        if(val==1)
        {
        //if(password.equals("admin123")){  

            out.print("You are successfully logged in!");  
            out.print("<br>Welcome, "+user);  
              
            Cookie ck=new Cookie("user",user);  
            response.addCookie(ck);  
            response.sendRedirect("index.jsp");
        }else{  
            
            out.print("sorry, username or password error!");  
           request.getRequestDispatcher("login.html").include(request, response); 
        }  
          
        out.close();  
    }  
    
    
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
        
 }
 public int validate(String user,String password)
 {
        Connection con=null;
               try {
                     Class.forName("org.apache.derby.jdbc.ClientDriver");
                     //Class.forName("oracle.jdbc.driver.OracleDriver");
               } catch (ClassNotFoundException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
               }
               
               try {
                      con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample","user","user");
                     //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
               } catch (SQLException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
               }
        int flag=0;
        //Connection con = ConnectionManager.getConnection();
        Statement stmt=null;
        ResultSet resultset = null;
       // String Query = "SELECT *from T_XBBNHGN_REGISTER";
        String Query = "SELECT * from T_XBBNHGN_REGISTER where name='"+user+"'";
        try {
               stmt=con.createStatement();
               resultset = stmt.executeQuery(Query);   
               while(resultset.next())
               {
                      System.out.println(resultset.getString(1)+resultset.getString(2)+resultset.getString(3));
                     if(resultset.getString(3).equals(password))
                     {
                        flag=1;
                       // System.out.println(flag);
                        break;
                     }
               }
               if(flag==1)
               {
                     return 1;
                     //System.out.println("True");
               }
               else
               {
               return 0;
                     //System.out.println("False");
               }
               
        } catch (SQLException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
               return 0;
        }
 }
    }

