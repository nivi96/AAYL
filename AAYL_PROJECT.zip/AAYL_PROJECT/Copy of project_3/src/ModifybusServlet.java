import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class ModifybusServlet extends HttpServlet {
	 protected void doGet(HttpServletRequest request, HttpServletResponse response)  
	            throws ServletException, IOException {  
	response.setContentType("text/html");  
	PrintWriter out=response.getWriter();  

	HttpSession session=request.getSession(false);  
    if(session!=null){  
	//request.getRequestDispatcher("link.html").include(request, response);  

	int busid=Integer.parseInt(request.getParameter("busid"));  
	//String option=request.getParameter("option");
	if(request.getParameter("option").equals("seats")||request.getParameter("option").equals("fare"))
	{
		String option1=request.getParameter("option");
		int p1=Integer.parseInt(request.getParameter("parameter"));
		//int busid=Integer.parseInt(request.getParameter("busid"));
		//int busid1=Integer.parseInt(request.getParameter("busid"));
		//System.out.println(busid1);
		
		int val = 0 ;
		try {
			val = validate1(busid,option1,p1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(val==1)
		{
		//if(password.equals("admin123")){  
			String message = "Details successfully modified!";
			request.setAttribute("message",message);
			RequestDispatcher dispatcher = request.getRequestDispatcher("modifybus.jsp");
			dispatcher.forward( request, response ); 
		//out.print("<br>Welcome, "+user);  

		//Cookie ck=new Cookie("user",user);  
		//response.addCookie(ck);  
		//response.sendRedirect("home.jsp");
		}else{  

			String message = "Sorry error occured!.....Try Again!!!!!!!";
			
			request.setAttribute("message",message);
			RequestDispatcher dispatcher = request.getRequestDispatcher("modifybus.jsp");
			dispatcher.forward( request, response );   
		//request.getRequestDispatcher("Signup.html").include(request, response); 
		}  

		out.close();  
		
		}  

	
	else
	{
		String option=request.getParameter("option");
		String p=request.getParameter("parameter");
		
		int val = 0 ;
		try {
			val = validate(busid,option,p);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(val==1)
		{
		//if(password.equals("admin123")){  
			String message = "Details successfully modified!";
			request.setAttribute("message",message);
			RequestDispatcher dispatcher = request.getRequestDispatcher("modifybus.jsp");
			dispatcher.forward( request, response ); 
		//out.print("Details successfully modified!");  
		//out.print("<br>Welcome, "+user);  

		//Cookie ck=new Cookie("user",user);  
		//response.addCookie(ck);  
		//response.sendRedirect("home.jsp");
		}else{  

String message = "Sorry error occured!.....Try Again!!!!!!!";
			
			request.setAttribute("message",message);
			RequestDispatcher dispatcher = request.getRequestDispatcher("modifybus.jsp");
			dispatcher.forward( request, response );   
		//out.println("sorry error occurred.........!");  
		//out.println("TryAgain!!");
		//request.getRequestDispatcher("Signup.html").include(request, response); 
		}  

		out.close();  
		} }
    else{  
	    out.print("Please login first");  
	    request.getRequestDispatcher("index.jsp").include(request, response);  
	}



	
	
	
	//System.out.println(user+email+password+passwordr);
	

	
	}  



	//protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	//doGet(request, response);

	//}
	public int validate(int busid,String option,String p) throws SQLException
	{
	Connection con=null;
	int flag = 0;
	try {
	      Class.forName("org.apache.derby.jdbc.ClientDriver");
	      //Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	try {
	       con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample","user","user");
	      //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
	} catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	//Connection con = ConnectionManager.getConnection();
	try{
	PreparedStatement stmt1=null;
	Statement stmt=null;
	//ResultSet resultset=null;


				
	//System.out.println("Enter the detail you have to modify:");
	//System.out.println("1.Bustype\n2.fromstation\n3.tostation\n4.arrivaltime\n5.departuretime\n6.traveltime\n7.route\n8.fare\n9.seat");

	
		System.out.println(option);
		switch(option)
		{
		case "Bus type":
		{
			//stmt =con.createStatement();
			String searchQuery1= "update T_XBBNHGN_BUS set bus_type=? where bus_id=?";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,busid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
			// System.out.println(p);
			   System.out.println("Bustype updated succesfully");
	}break;
		
		case "departure station":
		{
			
			//stmt =con.createStatement();
			
			String searchQuery1= "update T_XBBNHGN_BUS set from_station=? where bus_id=? ";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,busid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("station updated succesfully");
		}break;
		case "Arrival station":
		{
			
			
			
			String searchQuery1= "update T_XBBNHGN_BUS set to_station=? where bus_id=?";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,busid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("station updated succesfully");
		}break;
		case "Arrival time":
		{
			
			String searchQuery1= "update T_XBBNHGN_BUS set arrival_time=? where bus_id=?";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,busid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("Time updated succesfully");
		}break;
		case "departure time":
		{
			
			String searchQuery1= "update T_XBBNHGN_BUS set departure_time=? where bus_id=?";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,busid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("Time updated succesfully");
			
		}break;
		case "travel time":
		{
			
			
			String searchQuery1= "update T_XBBNHGN_BUS set travel_time=? where bus_id=?";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,busid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("Travel time updated succesfully");
		}break;
		case "route":
		{
			
			
			String searchQuery1= "update T_XBBNHGN_BUS set route=? where bus_id=? ";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setString(1,p);
			stmt1.setInt(2,busid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("Route updated succesfully");
		}break;
		}}
		catch (SQLException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		}
		if(flag==1)
		{
		      return 1;
		      //System.out.println("True");
		}
		else
		{
		return 0;
		      //System.out.println("False");
		}
	
	}
	public int validate1(int busid,String option1,int p1) throws SQLException
	{
	Connection con=null;
	int flag = 0;
	
	try {
	      Class.forName("org.apache.derby.jdbc.ClientDriver");
	      //Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	try {
	       con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample","user","user");
	      //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
	} catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	//Connection con = ConnectionManager.getConnection();
	try{
	PreparedStatement stmt1=null;
	Statement stmt=null;
	//ResultSet resultset=null;


				
	//System.out.println("Enter the detail you have to modify:");
	//System.out.println("1.Bustype\n2.fromstation\n3.tostation\n4.arrivaltime\n5.departuretime\n6.traveltime\n7.route\n8.fare\n9.seat");

	
		
		switch(option1)
		{
	
		case "fare":
		{
			//System.out.println(busid1);
			
			String searchQuery1= "update T_XBBNHGN_BUS set fare=? where bus_id=? ";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setInt(1,p1);
			stmt1.setInt(2,busid);
			//System.out.println(p1);
		
			flag= stmt1.executeUpdate();
				   System.out.println("Fare updated succesfully");
		}break;
		case "seats":
		{
			
			
			String searchQuery1= "update T_XBBNHGN_BUS set seats=? where bus_id=? ";
			stmt1=con.prepareStatement(searchQuery1);
			stmt1.setInt(1,p1);
			stmt1.setInt(2,busid);
			//System.out.println(p);
		
			flag= stmt1.executeUpdate();
				   System.out.println("seats updated succesfully");
		}break;
		

	}
	}
	catch (SQLException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

	if(flag==1)
	{
	      return 1;
	      //System.out.println("True");
	}
	else
	{
	return 0;
	      //System.out.println("False");
	}

	}
}
