import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class PaymentServlet extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();  

//request.getRequestDispatcher("link.html").include(request, response);  
HttpSession session=request.getSession(false);  
if(session!=null){  

int busid=Integer.parseInt(request.getParameter("id"));  

String journey_date=request.getParameter("journeydate"); 
int ticketid=Integer.parseInt(request.getParameter("ticketid"));
int customerid=Integer.parseInt(request.getParameter("customerid"));
String type=request.getParameter("type");
 
//System.out.println(user+email+password+passwordr);
int val = 0 ;
	try {
		val = validate(busid,journey_date,ticketid,customerid,type);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

if(val==1)
{
//if(password.equals("admin123")){  
	String message = "Successfully paid";
	//System.out.println(message);
	request.setAttribute("message",message);
	
	
	
//out.println("You are successfully added!");  
//out.print("<br>Welcome, "+user);  
//out.println("Your busid is"+busid);
//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
	RequestDispatcher dispatcher = request.getRequestDispatcher("Editprofilejsp.jsp");
	dispatcher.forward( request, response ); 

//out.print("You have successfully paid!"); 
request.getRequestDispatcher("paymentcash.jsp").include(request, response);
//out.print("<br>Welcome, "+user);  

//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
//response.sendRedirect("home.jsp");
}
/*else if(val==2)
{
	request.getRequestDispatcher("paymentcash.jsp").include(request, response);
}
else if(val==3)
{
	request.getRequestDispatcher("paymentcredit.jsp").include(request, response);
}
else if(val==4)
{
	request.getRequestDispatcher("paymentdebit.jsp").include(request, response);
}*/

else{  
	String message = "Sorry!!! error occured..try again!!";
	//System.out.println(message);
	request.setAttribute("message1",message);
	
	
	
//out.println("You are successfully added!");  
//out.print("<br>Welcome, "+user);  
//out.println("Your busid is"+busid);
//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
	RequestDispatcher dispatcher = request.getRequestDispatcher("Editprofilejsp.jsp");
	dispatcher.forward( request, response ); 

//request.getRequestDispatcher("Signup.html").include(request, response); 
}  

out.close();  
} else{  
    out.print("Please login first");  
    request.getRequestDispatcher("index.jsp").include(request, response);  
} }



//protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
//doGet(request, response);

//}
public int validate(int busid,String journey_date,int ticketid,int customerid,String type) throws SQLException
{
Connection con=null;
int flag = 0;
int val=0;
try {
  Class.forName("org.apache.derby.jdbc.ClientDriver");
//Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
      //Class.forName("oracle.jdbc.driver.OracleDriver");
} catch (ClassNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
}

try {
      // con=DriverManager.getConnection("jdbc:derby://172.24.21.35:1527/derby","user","user");
       con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample;create=true","user","pwd");
      //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
} catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
}

//Connection con = ConnectionManager.getConnection();
try{
PreparedStatement stmt1=null;
Statement stmt=null;
PreparedStatement statement=null;
//ResultSet resultset=null;

String sql="select * from T_XBBNHGN_BOOKING where ticket_id=?";

stmt1 =con.prepareStatement(sql);
stmt1.setInt(1,ticketid );

ResultSet resultset=stmt1.executeQuery();

 while(resultset.next())
	{
		//Paymentbean cbean=new Paymentbean();
						
			String sql11 = "INSERT INTO T_XBBNHGN_PAYMENT VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		statement = con.prepareStatement(sql11);
		statement.setInt(1, ticketid);
		statement.setInt(2,resultset.getInt(2));
		statement.setInt(3, customerid);
		statement.setString(4,resultset.getString(3));
		statement.setString(5,resultset.getString(4));
		statement.setString(6,resultset.getString(5));
		statement.setString(7,resultset.getString(6));
		statement.setString(8,resultset.getString(7));
		statement.setString(9,resultset.getString(8));
		statement.setInt(10,resultset.getInt(9));
		statement.setInt(11,resultset.getInt(10));
		statement.setInt(12,resultset.getInt(11));
		statement.setString(13, type);
		val = statement.executeUpdate();
		/*switch(type)
		{
		case "cash":
			val=2;
			break;
		case "credit card":
			val=3;
			break;
		case "debit card":
			val=4;
			break;
			
		}*/
			
		
		
		
 
 
 }

}
catch (SQLException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
}
return val;



}
}
 
