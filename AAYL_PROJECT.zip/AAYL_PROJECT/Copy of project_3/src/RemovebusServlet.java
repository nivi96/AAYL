import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class RemovebusServlet extends HttpServlet {
	 protected void doGet(HttpServletRequest request, HttpServletResponse response)  
	            throws ServletException, IOException {  
	response.setContentType("text/html");  
	PrintWriter out=response.getWriter();  
	HttpSession session=request.getSession(false);  
    if(session!=null){  
	//request.getRequestDispatcher("link.html").include(request, response);  

	int busid=Integer.parseInt(request.getParameter("busid"));  
	
	int val = 0 ;
	try {
		val = validate(busid);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

if(val==1)
{
//if(password.equals("admin123")){  
	String message = "successfully removed!";
	
	request.setAttribute("message",message);
	RequestDispatcher dispatcher = request.getRequestDispatcher("removejsp.jsp");
	dispatcher.forward( request, response );   
//out.print("<br>Welcome, "+user);  

//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
//response.sendRedirect("home.jsp");
}else{  
String message = "Sorry error occured!.....Try Again!!!!!!!";
	
	request.setAttribute("message",message);
	RequestDispatcher dispatcher = request.getRequestDispatcher("modifybus.jsp");
	dispatcher.forward( request, response );   
//request.getRequestDispatcher("Signup.html").include(request, response); 
}  

out.close();  
}
    else{  
	    out.print("Please login first");  
	    request.getRequestDispatcher("index.jsp").include(request, response);  
	}}  

	
	 public int validate(int busid) throws SQLException
	 {
	
	Connection con=null;
	int flag = 0;
	try {
	      Class.forName("org.apache.derby.jdbc.ClientDriver");
	      //Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	try {
	       con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample;create=true","user","user");
	      //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
	} catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}

	//Connection con = ConnectionManager.getConnection();
	try{
	PreparedStatement stmt1=null;
	Statement stmt=null;
	//ResultSet resultset=null;

	
	
	String searchQuery= "delete from T_XBBNHGN_BUS where bus_id=?";
	
	stmt1 =con.prepareStatement(searchQuery);
	stmt1.setInt(1,busid);
		flag= stmt1.executeUpdate();
		  
		System.out.println("Bus info deleted successfully"); 
	 }
	 catch (SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	}
	if(flag==0)
	{
	      return 0;
	      //System.out.println("True");
	}
	else
	{
	return 1;
	      //System.out.println("False");
	}
	
	 }

}
