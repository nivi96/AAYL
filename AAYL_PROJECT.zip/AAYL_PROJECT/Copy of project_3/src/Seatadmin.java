import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class Seatadmin extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();  
    




//request.getRequestDispatcher("link.html").include(request, response);  


int busid=Integer.parseInt(request.getParameter("bid"));  

String journey_date=request.getParameter("journeydate"); 
Random randomGenerator = new Random();

int randomInt = randomGenerator.nextInt(100);
int ticketid=randomInt;
//int ticketid=Integer.parseInt(request.getParameter("ticketid"));
String customerid=request.getParameter("cid");
//String type=request.getParameter("type");
 
//System.out.println(user+email+password+passwordr);
int val = 0 ;
	try {
		val = validate(busid,journey_date,ticketid,customerid);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

if(val==1)
{
//if(password.equals("admin123")){  

	String message = "You are successfully paid!";
	//System.out.println(message);
	request.setAttribute("message",message);
	
	String message1 = "Your ticketid  is"+ticketid;
	//System.out.println(message);
	request.setAttribute("message1",message1);
	
	
	
//out.println("You are successfully added!");  
//out.print("<br>Welcome, "+user);  
//out.println("Your busid is"+busid);
//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
	RequestDispatcher dispatcher = request.getRequestDispatcher("Bookjsp.jsp");
	dispatcher.forward( request, response ); 
//request.getRequestDispatcher("Loginadmin.html").include(request, response);
//out.print("<br>Welcome, "+user);  

//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
//response.sendRedirect("home.jsp");
}
/*else if(val==2)
{
	request.getRequestDispatcher("paymentcash.jsp").include(request, response);
}
else if(val==3)
{
	request.getRequestDispatcher("paymentcredit.jsp").include(request, response);
}
else if(val==4)
{
	request.getRequestDispatcher("paymentdebit.jsp").include(request, response);
}*/

else{  

	String message1 = "Sorry..!!Try again";
	//System.out.println(message);
	request.setAttribute("message1",message1);
	
	
	
//out.println("You are successfully added!");  
//out.print("<br>Welcome, "+user);  
//out.println("Your busid is"+busid);
//Cookie ck=new Cookie("user",user);  
//response.addCookie(ck);  
	RequestDispatcher dispatcher = request.getRequestDispatcher("FillProfile.jsp");
	dispatcher.forward( request, response ); 
//request.getRequestDispatcher("Signup.html").include(request, response); 
}  

out.close();  
}  



//protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
//doGet(request, response);

//}
public int validate(int busid,String journey_date,int ticketid,String customerid) throws SQLException
{
Connection con=null;
int flag = 0;
int val=0;
try {
  Class.forName("org.apache.derby.jdbc.ClientDriver");
//Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
      //Class.forName("oracle.jdbc.driver.OracleDriver");
} catch (ClassNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
}

try {
      // con=DriverManager.getConnection("jdbc:derby://172.24.21.35:1527/derby","user","user");
       con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample;create=true","user","pwd");
      //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
} catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
}

//Connection con = ConnectionManager.getConnection();
try{
PreparedStatement stmt1=null;
Statement stmt=null;
PreparedStatement statement=null;
//ResultSet resultset=null;


	//System.out.println("Enter journey date:");
	//String journeydate=in.nextLine();
	//System.out.println("Enter bus_id");

	//System.out.println("Enter ticket_id");
	//int ticketid=in.nextInt();
	
	int totalfare = 0;
	String sql="select fare,seats from T_XBBNHGN_TICKETuser where journey_date=? and bus_id=?";

		stmt1 =con.prepareStatement(sql);
		stmt1.setString(1,journey_date );
		stmt1.setInt(2, busid);
		ResultSet resultset=stmt1.executeQuery();
		while(resultset.next())
		{
			int fare=resultset.getInt(1);
			
			int noofseats=resultset.getInt(2);
		totalfare=fare*noofseats;
			
			
		
		System.out.println("Totalfare is:"+totalfare);
		String sql1 = "select * from T_XBBNHGN_Ticketadmin where journey_date=? and bus_id=? ";
		statement = con.prepareStatement(sql1);
		statement.setString(1,journey_date );
		statement.setInt(2, busid);
		//stmt11.setString(3, tostation);
		//System.out.println("hi"); 
		resultset=statement.executeQuery();
	//System.out.println(resultset);
		 while(resultset.next())
			{
				//Ticketbean cbean=new Ticketbean();
								
					//cbean.setBus_id(resultset.getInt(1));
					//cbean.setBustype(resultset.getString(2));
				//System.out.println(resultset);
				//clist.add(cbean); 
			
			
		 //String  searchQuery1="insert into T_XBBNHGN_TICKET values '"+journeydate+"' select bus_id,bus_type,from_station,to_station,arrival_time,departure_time,fare,seats from T_XBBNHGN_BUS where bus_type= '"+bustype+"' and from_station='"+fromstation+"'  and to_station= '"+tostation+"' ";
		 //String  searchQuery1="insert into T_XBBNHGN_TICKET values( '"+journeydate+"','"+resultset.getInt(1)+"','"+resultset.getString(2)+"','"+resultset.getString(3)+"','"+resultset.getString(4)+"','"+resultset.getString(5)+"','"+resultset.getString(6)+"','"+resultset.getInt(9)+"','"+resultset.getInt(10)+"' )";
		 //String s1="insert into T_XBBNHGN_TICKET(journey_date) values '"+journeydate+"'where bus_type= '"+bustype+"' and from_station='"+fromstation+"'  and to_station= '"+tostation+"' ";
		 //val=stmt1.executeUpdate(searchQuery1);			 
		// stmt.executeUpdate(s1);
				//System.out.println("hii");
				String sql11 = "INSERT INTO T_XBBNHGN_BOOKING VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
				statement = con.prepareStatement(sql11);
				statement.setInt(1,ticketid);
				statement.setInt(2,busid);
				statement.setString(3, journey_date);
			
				
				statement.setString(4, resultset.getString(3));
				statement.setString(5,resultset.getString(4));
				statement.setString(6,resultset.getString(5));
				statement.setString(7,resultset.getString(6));
				statement.setString(8,resultset.getString(7));
				statement.setInt(9,resultset.getInt(8));
				statement.setInt(10,noofseats);
				statement.setInt(11, totalfare);
				val = statement.executeUpdate();
				
		 
		 
		 }
		 

		}

}catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
return val;

}
}