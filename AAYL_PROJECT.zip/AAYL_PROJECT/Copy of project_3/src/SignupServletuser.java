import java.io.IOException;
	import java.io.PrintWriter;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
	import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
	import javax.servlet.http.Cookie;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;
public class SignupServletuser	extends HttpServlet {  
		    protected void doGet(HttpServletRequest request, HttpServletResponse response)  
		                           throws ServletException, IOException {  
		        response.setContentType("text/html");  
		        PrintWriter out=response.getWriter();  
		        HttpSession session=request.getSession(false);  
		         if(session!=null){     
		        //request.getRequestDispatcher("link.html").include(request, response);  
		          
		        String user=request.getParameter("uname");  
		        String email=request.getParameter("email"); 
		        String password=request.getParameter("psw");  
		        String passwordr=request.getParameter("pswr"); 
		        System.out.println(user+email+password+passwordr);
		        int val=validate(user,email,password,passwordr);
		        if(val==1)
		        {
		        //if(password.equals("admin123")){  

		           // String message="You are successfully Signed in!";  
		         //   request.setAttribute("message",message);

out.print("You are successfully signed in!..");

		          
		       

		          //out.print("You have successfully paid!"); 
		          request.getRequestDispatcher("paymentcash.jsp").include(request, response);
		              
		            Cookie ck=new Cookie("user",user);  
		            response.addCookie(ck);  
		            response.sendRedirect("userlogin.jsp");
		        }else{  
		            
		            out.println("sorry password error!");  
		            out.println("TryAgain!!");
		           request.getRequestDispatcher("Signupuser.html").include(request, response); 
		        }  
		          
		        out.close();  
		    }   else{  
			    out.print("Please login first");  
			    request.getRequestDispatcher("userlogin.jsp").include(request, response);  
			}}
		    
		    
		    
		    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        // TODO Auto-generated method stub
		        doGet(request, response);
		        
		 }
		 public int validate(String user,String email,String password,String passwordr)
		 {
		        Connection con=null;
		               try {
		                     Class.forName("org.apache.derby.jdbc.ClientDriver");
		                     //Class.forName("oracle.jdbc.driver.OracleDriver");
		               } catch (ClassNotFoundException e) {
		                     // TODO Auto-generated catch block
		                     e.printStackTrace();
		               }
		               
		               try {
		                      con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample","user","user");
		                     //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
		               } catch (SQLException e) {
		                     // TODO Auto-generated catch block
		                     e.printStackTrace();
		               }
		        int flag=0;
		        //Connection con = ConnectionManager.getConnection();
		        Statement stmt=null;
		        ResultSet resultset = null;
		       // String Query = "SELECT *from T_XBBNHGN_REGISTER";
		        if(password.equals(passwordr))
				{
					
			String searchQuery= "insert into T_XBBNHGN_REGISTER values('"+user+"','"+email+"','"+password+"','"+passwordr+"') ";
				 try {
					 System.out.println(searchQuery);
					 stmt =con.createStatement();
					stmt.executeUpdate(searchQuery);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				  // clist=new ArrayList<Registrationbean>();
				System.out.println("Registered successfully");   
				flag=1;
			}
				
				else
				{
					System.out.println("pwd does not match");
				}
			
		               if(flag==1)
		               {
		                     return 1;
		                     //System.out.println("True");
		               }
		               else
		               {
		               return 0;
		                     //System.out.println("False");
		               }
		               
		        } 
		      
		 }
		




