import java.io.IOException;
	import java.io.PrintWriter;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.ResultSetMetaData;

	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;

public class TicketjoinServlet extends HttpServlet{
		 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  	   response.setContentType("text/html");  
	  	   PrintWriter out = response.getWriter();  
	  	// request.getRequestDispatcher("link.html").include(request, response); 
	         
	         HttpSession session=request.getSession(false);  
	         if(session!=null){          
	  	    
	  	   //System.out.println(journeydate+arrival_station+departure_station);
	  	

	  	             
	  	  try{  
	  	   //Class.forName("oracle.jdbc.driver.OracleDriver");  
	  		   Class.forName("org.apache.derby.jdbc.ClientDriver");
	  	  // Connection con=DriverManager.getConnection( "jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
	           Connection  con=DriverManager.getConnection("jdbc:derby://172.24.18.21:1527/sample","user","user");

	  	                 
	  	   PreparedStatement ps=con.prepareStatement("SELECT distinct s1.ticket_id, s2.name FROM T_XBBNHGN_PAYMENT s1 INNER JOIN T_XBBNHGN_PROFILE s2 ON s1.customer_id=s2.customer_id");  
	  	   //ps.setString(1,journeydate);  
	  	   
	  	                 
	  	   out.print("<table width=50% border=1>");  
	  	   out.print("<caption>Bus Details</caption>");  
	  	     
	  	   ResultSet rs=ps.executeQuery();  
	  	                 
	  	   /* Printing column names */  
	  	ResultSetMetaData rsmd=rs.getMetaData();  
	  	   int total=rsmd.getColumnCount();  
	  	   out.print("<tr>");  
	  	   for(int i=1;i<=total;i++)  
	  	   {  
	  	   out.print("<th>"+rsmd.getColumnName(i)+"</th>");  
	  	   }  
	  	     
	  	   out.print("</tr>");  
	  	                 
	  	   /* Printing result */  
	  	     
	  	  while(rs.next())  
	  	   {  
	  	   out.print("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td></tr>");
	  			
	  	                     
	  	   }  
	  	     
	  	   out.print("</table>");  
	  	                 
	  	   }catch (Exception e2) {e2.printStackTrace();}  
	  	             
	  	   finally{out.close();}  
	  	     
	  	   }
	         else{  
	             out.print("Please login first");  
	             request.getRequestDispatcher("index.jsp").include(request, response);  
	         } 
	     }
	     
	}



