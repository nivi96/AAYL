package spring;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Scanner;

public class BookticketDao {
	Connection con=ConnectionManager.getConnection();
	PreparedStatement stmt1=null;
	PreparedStatement statement=null;
	Statement stmt=null;
	int val=0;
	void bookticketdetails()
	{
	Scanner in=new Scanner(System.in);
	System.out.println("Do you want to book ticket(yes/no)");
	String str=in.nextLine();
	if(str.equalsIgnoreCase("yes"))
	{	try {
		System.out.println("Enter journey date:");
		String journeydate=in.nextLine();
		System.out.println("Enter bus_id");
		int busid=in.nextInt();
		//System.out.println("Enter ticket_id");
		//int ticketid=in.nextInt();
		Random randomGenerator = new Random();
	   
	      int randomInt = randomGenerator.nextInt(100);
	      int ticketid=randomInt;
		int totalfare = 0;
		String sql="select fare,seats from T_XBBNHGN_TICKETuser where journey_date=? and bus_id=?";
	
			stmt1 =con.prepareStatement(sql);
			stmt1.setString(1,journeydate );
			stmt1.setInt(2, busid);
			ResultSet resultset=stmt1.executeQuery();
			while(resultset.next())
			{
				int fare=resultset.getInt(1);
				
				int noofseats=resultset.getInt(2);
			totalfare=fare*noofseats;
				
				
			}
			System.out.println("Totalfare is:"+totalfare);
			String sql1 = "select * from T_XBBNHGN_Ticketadmin where journey_date=? and bus_id=? ";
			statement = con.prepareStatement(sql1);
			statement.setString(1,journeydate );
			statement.setInt(2, busid);
			//stmt11.setString(3, tostation);
			//System.out.println("hi"); 
			resultset=statement.executeQuery();
		//System.out.println(resultset);
			 while(resultset.next())
				{
					//Ticketbean cbean=new Ticketbean();
									
						//cbean.setBus_id(resultset.getInt(1));
						//cbean.setBustype(resultset.getString(2));
					//System.out.println(resultset);
					//clist.add(cbean); 
				
				
			 //String  searchQuery1="insert into T_XBBNHGN_TICKET values '"+journeydate+"' select bus_id,bus_type,from_station,to_station,arrival_time,departure_time,fare,seats from T_XBBNHGN_BUS where bus_type= '"+bustype+"' and from_station='"+fromstation+"'  and to_station= '"+tostation+"' ";
			 //String  searchQuery1="insert into T_XBBNHGN_TICKET values( '"+journeydate+"','"+resultset.getInt(1)+"','"+resultset.getString(2)+"','"+resultset.getString(3)+"','"+resultset.getString(4)+"','"+resultset.getString(5)+"','"+resultset.getString(6)+"','"+resultset.getInt(9)+"','"+resultset.getInt(10)+"' )";
			 //String s1="insert into T_XBBNHGN_TICKET(journey_date) values '"+journeydate+"'where bus_type= '"+bustype+"' and from_station='"+fromstation+"'  and to_station= '"+tostation+"' ";
			 //val=stmt1.executeUpdate(searchQuery1);			 
			// stmt.executeUpdate(s1);
					//System.out.println("hii");
					String sql11 = "INSERT INTO T_XBBNHGN_BOOKING VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
					statement = con.prepareStatement(sql11);
					statement.setInt(1,ticketid);
					statement.setInt(2,busid);
					statement.setString(3, journeydate);
				
					
					statement.setString(4, resultset.getString(3));
					statement.setString(5,resultset.getString(4));
					statement.setString(6,resultset.getString(5));
					statement.setString(7,resultset.getString(6));
					statement.setString(8,resultset.getString(7));
					statement.setInt(9,resultset.getInt(8));
					statement.setInt(10,resultset.getInt(9));
					statement.setInt(11, totalfare);
					val = statement.executeUpdate();
					
			 
			 
			 }
			 

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	else
		System.out.println("Thank you!!!");
	}
	

}
