package spring;


	import java.sql.SQLException;
import java.util.ArrayList;
	import java.util.List;

	import org.springframework.http.MediaType;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;
	import org.springframework.web.bind.annotation.RequestParam;
	import org.springframework.web.bind.annotation.RestController;

	/*import daobean.AdminBean;
	import daobean.AdminDAO;
	import daobean.TemplatesDAO;*/



	@RestController
	@RequestMapping(value = "/bus")
	public class BusController {


	                
	                
	                  @RequestMapping(value = "/select" , method = RequestMethod.GET )
	                  public List<Busbean> getAllTemplates() throws SQLException {
	                                  BusDao td = new   BusDao();
	                                ArrayList<Busbean> list = (ArrayList<Busbean>) td.getbus();  
	                return list;
	      }      
	                  @RequestMapping(value = "/delete/{id}" , method = RequestMethod.DELETE )
	                  public int removeRecord(@PathVariable("id") int id) throws SQLException {
	                	  BusDao td = new BusDao();
	                                int n = td.remove(id);  
	                return n;
	    }



}
