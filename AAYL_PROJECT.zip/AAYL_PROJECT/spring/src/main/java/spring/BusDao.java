package spring;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;





public class BusDao {
	
	Connection con=ConnectionManager.getConnection();
	PreparedStatement stmt1=null;
	PreparedStatement statement=null;
	Statement stmt=null;
	int val=0;
	List clist=null;
	
	List<Busbean> getbus() throws SQLException	{
		
		
		
		 PreparedStatement ps=con.prepareStatement("select distinct *from  T_XBBNHGN_Bus");  
		//  ps.setInt(1,ticket_id);
		                 
		  
		     
		   ResultSet rs=ps.executeQuery();  
			clist=new ArrayList<Busbean>();
		   while(rs.next()) 
		   {
			  Busbean cbean=new Busbean();
				
				
				
				cbean.setBusid(rs.getInt(1));
				
				cbean.setBustype(rs.getString(2));
				cbean.setFromstation(rs.getString(3));
				cbean.setTostation(rs.getString(4));
				cbean.setArrivaltime(rs.getString(5));
				cbean.setDeparturetime(rs.getString(6));
				cbean.setTraveltime(rs.getString(7));
				cbean.setRoute(rs.getString(8));
				cbean.setFare(rs.getInt(9));
				cbean.setNoofseats(rs.getInt(10));
				
			
				
				
				
			
				clist.add(cbean);

		   }
		return clist;
		   

	

}
	
	
	
	
	int remove(int busid) throws SQLException	{
		
		String searchQuery= "delete from T_XBBNHGN_BUS where bus_id=?";
		statement.setInt(1, busid);
				
		 int result=statement.executeUpdate(searchQuery);
		 System.out.println(result);
		return result;
		
		}
}




/*void filldetails(String bus)
{
	
}*/
	/*public List<Busbean> getbusdetails()
	{
		
		Connection con=ConnectionManager.getConnection();
		PreparedStatement stmt1=null;
		Statement stmt=null;
		//ResultSet resultset=null;
		List<Busbean> clist=null;
		try {
			Scanner in=new Scanner(System.in);
			System.out.println("Welcome admin:");
			System.out.println("1.Add buses\n2.Remove buses\n3.modify bus details");
			int n=in.nextInt();
			switch(n)
			{
			case 1:
			{
			
			System.out.println("Enter busid:");
			int busid=in.nextInt() ;
			in.nextLine();
			System.out.println("Enter bustype:");
			String bustype=in.nextLine();
			System.out.println("Enter fromstation");
			String fromstation=in.nextLine();
			System.out.println("Enter tostation");
			String tostation=in.nextLine();
			System.out.println("Enter arrivaltime");
			String arrivaltime=in.nextLine();
			System.out.println("Enter departuretime");
			String departuretime=in.nextLine();
			System.out.println("Enter travel time:");
			String traveltime=in.nextLine();
			System.out.println("Enter route");
			String route=in.nextLine();
			System.out.println("Enter fare:");
			int fare=in.nextInt();
			System.out.println("Enter no of seats:");
			int seats=in.nextInt();
			in.nextLine();
			System.out.println(busid+bustype+fromstation+tostation+arrivaltime+" "+departuretime+traveltime+route+fare+seats);
					
		String searchQuery= "insert into T_XBBNHGN_BUS (bus_id,bus_type,from_station,to_station,arrival_time,departure_time,travel_time,route,fare,seats) values(?,?,?,?,?,?,?,?,?,?) ";
		stmt1 =con.prepareStatement(searchQuery);	
		stmt1.setInt(1,busid);
		stmt1.setString(2,bustype);
		stmt1.setString(3,fromstation);
		stmt1.setString(4,tostation);
		stmt1.setString(5,arrivaltime);
		stmt1.setString(6,departuretime);
		stmt1.setString(7,traveltime);
		stmt1.setString(8,route);
		stmt1.setInt(9,fare);
		stmt1.setInt(10,seats);
		int resultset = stmt1.executeUpdate();
			   //clist=new ArrayList<Busbean>();
			System.out.println("Bus added successfully");   
		}break;
			case 2:
			{
				System.out.println("Enter busid:");
				int busid=in.nextInt();
				in.nextLine();
				stmt =con.createStatement();
				
				String searchQuery= "delete from T_XBBNHGN_BUS where bus_id='"+busid+"'";
					 stmt.executeUpdate(searchQuery);
					  
					System.out.println("Bus info deleted successfully"); 
			}break;
			case 3:
			{
				System.out.println("Enter the detail you have to modify:");
				System.out.println("1.Bustype\n2.fromstation\n3.tostation\n4.arrivaltime\n5.departuretime\n6.traveltime\n7.route\n8.fare\n9.seat");
				int n1=in.nextInt();
				switch(n1)
				{
				case 1:
				{
					System.out.println("Enter busid:");
					int busid=in.nextInt();
					in.nextLine();
					System.out.println("Enter bustype:");
					String bustype=in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_BUS set bus_type='"+bustype+"'where bus_id='"+busid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Busbean>();
						   System.out.println("Bustype updated succesfully");
				}break;
				case 2:
				{
					System.out.println("Enter busid:");
					int busid=in.nextInt();
					in.nextLine();
					System.out.println("Enter fromstation:");
					String fromstation=in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_BUS set from_station='"+fromstation+"'where bus_id='"+busid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Busbean>();
						   System.out.println("station updated succesfully");
				}break;
				case 3:
				{
					System.out.println("Enter busid:");
					int busid=in.nextInt();
					in.nextLine();
					System.out.println("Enter tostation:");
					String tostation=in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_BUS set to_station='"+tostation+"'where bus_id='"+busid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Busbean>();
						   System.out.println("station updated succesfully");
				}break;
				case 4:
				{
					System.out.println("Enter busid:");
					int busid=in.nextInt();
					in.nextLine();
					System.out.println("Enter arrivaltime:");
					String arrivaltime=in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_BUS set arrival_time='"+arrivaltime+"'where bus_id='"+busid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Busbean>();
						   System.out.println("Time updated succesfully");
				}break;
				case 5:
				{
					System.out.println("Enter busid:");
					int busid=in.nextInt();
					in.nextLine();
					System.out.println("Enter departuretime:");
					String departuretime=in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_BUS set departure_time='"+departuretime+"'where bus_id='"+busid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Busbean>();
						   System.out.println("Time updated succesfully");
					
				}break;
				case 6:
				{
					System.out.println("Enter busid:");
					int busid=in.nextInt();
					in.nextLine();
					System.out.println("Enter traveltime:");
					String traveltime=in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_BUS set travel_time='"+traveltime+"'where bus_id='"+busid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Busbean>();
						   System.out.println("Travel time updated succesfully");
				}break;
				case 7:
				{
					System.out.println("Enter busid:");
					int busid=in.nextInt();
					in.nextLine();
					System.out.println("Enter route:");
					String route=in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_BUS set route='"+route+"'where bus_id='"+busid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Busbean>();
						   System.out.println("Route updated succesfully");
				}break;
				case 8:
				{
					System.out.println("Enter busid:");
					int busid=in.nextInt();
					in.nextLine();
					System.out.println("Enter fare:");
					int fare=in.nextInt();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_BUS set fare='"+fare+"'where bus_id='"+busid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Busbean>();
						   System.out.println("Fare updated succesfully");
				}break;
				case 9:
				{
					System.out.println("Enter busid:");
					int busid=in.nextInt();
					in.nextLine();
					System.out.println("Enter no of seats:");
					int seats=in.nextInt();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_BUS set seat='"+seats+"'where bus_id='"+busid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Busbean>();
						   System.out.println("seats updated succesfully");
				}break;
				
				
				
				
			}
			}
		}
		}
			
			
		
		catch (SQLException e) {
			e.printStackTrace();
		}
		/*finally
		{
		try
		{
			//resultset.close();
			//stmt.close();
			//stmt1.close();
		//	con.close();
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		}*/
			
			//return clist;
	//}

//}
