package spring;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//import com.bku.inautix.model.StockBean;
import spring.Profilebean;



@RestController
@RequestMapping(value = "/stocks")

public class ProfileController {

	@RequestMapping(value = "/select" , method = RequestMethod.GET )
    public List<Profilebean> getAllTemplates() throws SQLException {
                    ProfileDao td = new  ProfileDao();
                  ArrayList<Profilebean> list = (ArrayList<Profilebean>) td.getprofiledetails();  
  return list;
}        

  


    
}
