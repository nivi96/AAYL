package spring;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;





public class ProfileDao {
	public List<Profilebean> getprofiledetails() throws SQLException
	{
		Connection con=ConnectionManager.getConnection();
		PreparedStatement stmt1=null;
	Statement stmt=null;
		//ResultSet resultset=null;
		List<Profilebean> clist=null;
		Scanner in=new Scanner(System.in);
		/*try {
			
			System.out.println("Profile");
			System.out.println("1.complete profile:\n2.Edit profile");
			int n=in.nextInt();
			in.nextLine();
			switch(n)
			{
			case 1:
			{*/
			//System.out.println("Enter customerid(aadhar number)");
			//String customerid=in.nextLine();
			/*in.nextLine();
			System.out.println("Enter name:");
			String name=in.nextLine();
			System.out.println("Enter gender");
			String gender=in.nextLine();
			System.out.println("Enter age");
			int age=in.nextInt();
			in.nextLine();
			System.out.println("Enter address:");
			String address=in.nextLine();
			System.out.println("Enter city:");
			String city=in.nextLine();
			System.out.println("Enter contactno:");
			int contactno=in.nextInt();*/
			
			
			   clist=new ArrayList<Profilebean>();
		//String searchQuery= "insert into T_XBBNHGN_PROFILE values('"+customerid+"','"+name+"','"+gender+"','"+age+"','"+address+"','"+city+"','"+contactno+"') ";
			String searchQuery= "select distinct* from T_XBBNHGN_PROFILE ";	
			stmt1 =con.prepareStatement(searchQuery);
			//stmt1.setString(1,customerid);
			
			ResultSet val= stmt1.executeQuery();
			while(val.next())
			{
				Profilebean cbean=new Profilebean();
				cbean.setCustomerid(val.getInt(1));
				cbean.setName(val.getString(2));
				cbean.setGender(val.getString(3));
				cbean.setAge(val.getInt(4));
				cbean.setAddress(val.getString(5));
				cbean.setCity(val.getString(6));
				cbean.setContactno(val.getInt(7));
				
			clist.add(cbean);
			}
			
			   System.out.println("profile completed succesfully");
			return clist;
			
		}
	
	public List<Profilebean> getprofilesdetails() throws SQLException
	{
		Connection con=ConnectionManager.getConnection();
		PreparedStatement stmt1=null;
	Statement stmt=null;
		//ResultSet resultset=null;
		List<Profilebean> clist=null;
		Scanner in=new Scanner(System.in);
		/*try {
			
			System.out.println("Profile");
			System.out.println("1.complete profile:\n2.Edit profile");
			int n=in.nextInt();
			in.nextLine();
			switch(n)
			{
			case 1:
			{*/
			System.out.println("Enter customerid(aadhar number)");
			String customerid=in.nextLine();
			in.nextLine();
			System.out.println("Enter name:");
			String name=in.nextLine();
			System.out.println("Enter gender");
			String gender=in.nextLine();
			System.out.println("Enter age");
			int age=in.nextInt();
			in.nextLine();
			System.out.println("Enter address:");
			String address=in.nextLine();
			System.out.println("Enter city:");
			String city=in.nextLine();
			System.out.println("Enter contactno:");
			int contactno=in.nextInt();
			
			
			
		//String searchQuery= "insert into T_XBBNHGN_PROFILE values('"+customerid+"','"+name+"','"+gender+"','"+age+"','"+address+"','"+city+"','"+contactno+"') ";
			String searchQuery= "insert into T_XBBNHGN_PROFILE values(?,?,?,?,?,?,?) ";	
			stmt1 =con.prepareStatement(searchQuery);
			stmt1.setString(1,customerid);
			stmt1.setString(2,name);
			stmt1.setString(3,gender);
			stmt1.setInt(4, age);
			stmt1.setString(5,address);
			stmt1.setString(6,city);
			stmt1.setInt(7, contactno);
			int val= stmt1.executeUpdate();
			   clist=new ArrayList<Profilebean>();
			   System.out.println("profile completed succesfully");
			return clist;
			
		}
	public List<Profilebean> getprofileupdatedetails() throws SQLException
	{
		Connection con=ConnectionManager.getConnection();
		PreparedStatement stmt1=null;
	Statement stmt=null;
		//ResultSet resultset=null;
		List<Profilebean> clist=null;
		Scanner in=new Scanner(System.in);
			{
				System.out.println("Enter customerid(aadhar number)");
				String customerid=in.nextLine();
				System.out.println("Update profile");
				System.out.println("1.name\n2.gender\n3.age\n4.address\n5.city\n6.contactno");
				int n1=in.nextInt();
				in.nextLine();
				/*switch(n1)
				{
				case 1:	
				{*/
					System.out.println("Enter name:");
					String name=in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_PROFILE set name='"+name+"'where customer_id='"+customerid+"'";
						 try {
							stmt.executeUpdate(searchQuery1);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						   clist=new ArrayList<Profilebean>();
						   System.out.println("Name updated succesfully");
						
				}
			return clist;
	}
	/*break;
				case 2:
				{
					System.out.println("Enter gender:");
					String gender=in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_PROFILE set gender='"+gender+"'where customer_id='"+customerid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Profilebean>();
						   System.out.println("Gender updated succesfully");
				}
				break;
				case 3:
				{
					
						System.out.println("Enter age:");
						int age=in.nextInt();
						in.nextLine();
						stmt =con.createStatement();
						
						String searchQuery1= "update T_XBBNHGN_PROFILE set age='"+age+"'where customer_id='"+customerid+"'";
							 stmt.executeUpdate(searchQuery1);
							   clist=new ArrayList<Profilebean>();
							   System.out.println("Age updated succesfully");
					
				}break;
				case 4:
				{
					System.out.println("Enter address:");
					String address=in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_PROFILE set address='"+address+"'where customer_id='"+customerid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Profilebean>();
						   System.out.println("Address updated succesfully");
						   }break;
				case 5:
				{
					System.out.println("Enter city:");
					String city=in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_PROFILE set city='"+city+"'where customer_id='"+customerid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Profilebean>();
						   System.out.println("City updated succesfully");
				}break;
				case 6:
				{
					System.out.println("Enter contactno:");
					int contactno=in.nextInt();
					in.nextLine();
					stmt =con.createStatement();
					
					String searchQuery1= "update T_XBBNHGN_PROFILE set contact_no='"+contactno+"'where customer_id='"+customerid+"'";
						 stmt.executeUpdate(searchQuery1);
						   clist=new ArrayList<Profilebean>();
						   System.out.println("Contactno updated succesfully");
				}break;
					
				}
				
			}
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally
		{
		try
		{
			//resultset.close();
			//stmt.close();
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		}
			
			return clist;*/
	}



