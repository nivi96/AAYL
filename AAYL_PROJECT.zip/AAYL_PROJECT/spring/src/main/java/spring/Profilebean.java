package spring;

public class Profilebean {

String name;
String gender;
int age;
String address;
String city;
int contactno;
int customerid;
public int getCustomerid() {
	return customerid;
}
public void setCustomerid(int i) {
	this.customerid = i;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getContactno() {
	return contactno;
}
public void setContactno(int contactno) {
	this.contactno = contactno;
}
Profilebean()
{
	this.name=name;
	this.gender=gender;
	this.age=age;
	this.address=address;
	this.city=city;
	this.contactno=contactno;
	this.customerid=customerid;
}

}
