package spring;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//import com.bku.inautix.model.StockBean;
import spring.StockBean;

@RestController
@RequestMapping(value = "/stocks")

public class StockController {


	
	 
	  @RequestMapping(value = "/all" , method = RequestMethod.GET )
	  public List<StockBean> getAllStocks() {
    	
		ArrayList list = new ArrayList<StockBean>();  
		list.add(new StockBean("INFY", "INFOSYS TECHNOLOGIES"));
		
    	return list;
      }	

    
}
