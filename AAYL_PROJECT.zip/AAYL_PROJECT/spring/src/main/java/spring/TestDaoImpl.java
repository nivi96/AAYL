package spring;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import spring.ITestDao;
/*import com.nxn.tra.api.model.Test;*/
import spring.TestRowMapper;
import spring.Busbean;

@Component
public class TestDaoImpl extends JdbcDaoSupport implements ITestDao {

                @Autowired
                public TestDaoImpl(DataSource datasource) {
                                // TODO Auto-generated constructor stub
                                setDataSource(datasource);
                }

                @SuppressWarnings("unchecked")
				public List<Busbean> getBus() throws Exception {
                                // TODO Auto-generated method stub
                    List<Busbean> testList = null;

   testList = (List<Busbean>) getJdbcTemplate().query("select distinct * from T_XBBNHGN_BUS order by bus_id asc",new Object[] {}, (ResultSetExtractor) new TestRowMapper());

System.out.println(testList);
Iterator<Busbean> itr =testList.iterator();
for(Busbean b:testList)
{
                System.out.println(b.toString());
}
                                return testList;
                }

				public List<Busbean> getbus() throws Exception {
					// TODO Auto-generated method stub
					return null;
				}

               

}
