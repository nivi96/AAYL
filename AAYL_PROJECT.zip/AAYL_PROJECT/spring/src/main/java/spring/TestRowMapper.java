package spring;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import spring.Busbean;

public class TestRowMapper implements RowMapper {

    public Busbean mapRow(ResultSet rs, int rownum) throws SQLException {
           // TODO Auto-generated method stub
           
    	
    	
    	
    	Busbean cbean=new Busbean();
		
		
		
		cbean.setBusid(rs.getInt(1));
		
		cbean.setBustype(rs.getString(2));
		cbean.setFromstation(rs.getString(3));
		cbean.setTostation(rs.getString(4));
		cbean.setArrivaltime(rs.getString(5));
		cbean.setDeparturetime(rs.getString(6));
		cbean.setTraveltime(rs.getString(7));
		cbean.setRoute(rs.getString(8));
		cbean.setFare(rs.getInt(9));
		cbean.setNoofseats(rs.getInt(10));
           
           
           /*testObj.setTestDuration(rs.getString(3));*/
           /*testObj.setTestCreatedTs(DateFormatter.getNexenFormatDate(rs.getTimestamp(5)));
           System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" +rs.getTimestamp(5));
           System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" + DateFormatter.getNexenFormatDate(rs.getTimestamp(5)));
           testObj.setTestChargeBack(rs.getString(6));*/
           return cbean;
    }

}
