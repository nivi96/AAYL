package spring;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import spring.ticketdao;
import spring.Ticketbean;

public class TicketController {

	


	

	@RestController
	@RequestMapping(value = "/userdetails")
	public class SignUpController {
	@RequestMapping(value = "/all/{ticket_id}"  , method = RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE}) 
	         public List<Ticketbean> viewEmploy(@PathVariable ("ticket_id") int ticket_id) throws SQLException {
	      
	              ArrayList<Ticketbean> list1 = new ArrayList<Ticketbean>();  
	              ticketdao bdao=new ticketdao();
	     //list1= (ArrayList<Ticketbean>) bdao.bookticketdetails(ticket_id);
	     return list1;
	   }
	              
	       
	}

}
