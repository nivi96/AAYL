package spring;

public class Ticketbean {
int ticket_id;
public int getTicket_id() {
	return ticket_id;
}
public void setTicket_id(int ticket_id) {
	this.ticket_id = ticket_id;
}
public int getBus_id() {
	return bus_id;
}
public void setBus_id(int bus_id) {
	this.bus_id = bus_id;
}
public String getJourney_date() {
	return journey_date;
}
public void setJourney_date(String journey_date) {
	this.journey_date = journey_date;
}
public String getBus_type() {
	return bus_type;
}
public void setBus_type(String bus_type) {
	this.bus_type = bus_type;
}
public String getDeparture_station() {
	return departure_station;
}
public void setDeparture_station(String departure_station) {
	this.departure_station = departure_station;
}
public String getArrival_station() {
	return arrival_station;
}
public void setArrival_station(String arrival_station) {
	this.arrival_station = arrival_station;
}
public String getArrival_time() {
	return arrival_time;
}
public void setArrival_time(String arrival_time) {
	this.arrival_time = arrival_time;
}
public String getDeparture_time() {
	return departure_time;
}
public void setDeparture_time(String departure_time) {
	this.departure_time = departure_time;
}
public int getFare() {
	return fare;
}
public void setFare(int fare) {
	this.fare = fare;
}
public int getNoofseats() {
	return noofseats;
}
public void setNoofseats(int noofseats) {
	this.noofseats = noofseats;
}
public int getTotalfare() {
	return totalfare;
}
public void setTotalfare(int totalfare) {
	this.totalfare = totalfare;
}
int bus_id;
String journey_date;
String bus_type;
String departure_station;
String arrival_station;
String arrival_time;
String departure_time;
int fare;
int noofseats;
int totalfare;

}
