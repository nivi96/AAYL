package spring;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import org.apache.log4j.Logger;

public class ticketdao {
	
	final static Logger logger = Logger.getLogger(ticketdao.class);

	public void getAdminDetails()
	{
		Connection connection = ConnectionManager.getConnection();
		Statement statement = null;
		ResultSet rs = null;
		try {
			statement = connection.createStatement();
			rs = statement.executeQuery("Select * from T_XBBNHGN_BOOKING");
			while(rs.next())
			{
				logger.info(rs.getInt(1));
				   logger.info(rs.getInt(2));
				   logger.info(rs.getString(3));
				   logger.info(rs.getString(4));
				   logger.info(rs.getString(5));
				   logger.info(rs.getString(6));
				   logger.info(rs.getString(7));
				   logger.info(rs.getString(8));
				   logger.info(rs.getInt(9));
				   logger.info(rs.getInt(10));
				   logger.info(rs.getInt(11));
			}
			//result.close();
			//statement.executeUpdate("Update T_XBBNC94_Admin set Name = 'Preethi' where AdminID = '" + AdminId +"'");
			//statement.execute("Delete from T_XBBNC94_Staff where AdminID = '" + AdminId + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				rs.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	public static void main(String args[])
	{
		ticketdao adminDAO = new ticketdao();
		adminDAO.getAdminDetails();
	}

}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	



